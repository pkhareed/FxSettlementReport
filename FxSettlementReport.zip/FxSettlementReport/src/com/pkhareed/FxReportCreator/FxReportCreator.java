package com.pkhareed.FxReportCreator;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

public class FxReportCreator {

    public static void main(String[] args) {
        try {

            FxTradeFileParser fxParser = new FxTradeFileParser("testfxtrades.csv");
            ArrayList<String> fxLines = fxParser.readFile();
            FxTradeLedger fxLedger = new FxTradeLedger();

            for (String fx : fxLines) {
                String [] values = fx.split(",");

                //Date parsing
                SimpleDateFormat formatter=new SimpleDateFormat("dd MMM yyyy");
                Date instDate=formatter.parse(values[4]);
                Date settlemDate=formatter.parse(values[5]);
                LocalDateTime instLdt = LocalDateTime.ofInstant(instDate.toInstant(), ZoneId.systemDefault());
                LocalDateTime settlemLdt = LocalDateTime.ofInstant(settlemDate.toInstant(), ZoneId.systemDefault());

                //Fx Trade Object Creation
                FxTrade fxt = new FxTrade(values[0],
                        values[1].toUpperCase().charAt(0),
                        Double.valueOf(values[2]),
                        Currency.valueOf(values[3]),
                        instLdt,
                        settlemLdt,
                        Integer.valueOf(values[6]),
                        Double.valueOf(values[7])
                );
                fxLedger.storeTrade(fxt);
            }

            fxLedger.printFullFxSummaryReport();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
