package com.pkhareed.FxReportCreator;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Date;

public class FxTrade {
    private String _entity = null;
    private Character _side = null;
    private Double _agreedFx = null;
    private Currency _currency = null;
    private LocalDateTime _instructionDate = null;
    private LocalDateTime _settlementDate = null;
    private Long _units = null;
    private Double _pricePerUnit = null;
    private Double totalUSDCost = null;
    private String _separator = ", ";

    public void psep(){
        System.out.print(_separator);
    }
    public String get_entity() {
        return _entity;
    }

    public char get_side() {
        return _side;
    }

    public Double get_agreedFx() {
        return _agreedFx;
    }

    public Currency get_currency() {
        return _currency;
    }

    public String get_instructionDate() {
        return _instructionDate != null ? _instructionDate.toLocalDate().toString() : null;
    }

    public String get_settlementDate() {
        return _settlementDate != null ? _settlementDate.toLocalDate().toString() : null;
    }

    public long get_units() {
        return _units;
    }

    public Double get_pricePerUnit() {
        return _pricePerUnit;
    }
    public Double get_totalUSDCost() {
        return totalUSDCost;
    }

    // Settlement date correction as per the logic below
   /* A work week starts Monday and ends Friday, unless the currency of the trade is AED or SAR, where
    the work week starts Sunday and ends Thursday. No other holidays to be taken into account.
            • A trade can only be settled on a working day.
            • If an instructed settlement date falls on a weekend, then the settlement date should be changed to
    the next working day.*/
    private void fixSettlementDate(){
        if(_settlementDate != null && _currency != null){
            switch (_currency){
                case AED:
                case SAR:
                    if(_settlementDate.getDayOfWeek() == DayOfWeek.FRIDAY ){
                        _settlementDate = _settlementDate.plusDays(2);
                    }
                    if(_settlementDate.getDayOfWeek() == DayOfWeek.SATURDAY ){
                        _settlementDate = _settlementDate.plusDays(1);
                    }
                    break;
                default:
                    if(_settlementDate.getDayOfWeek() == DayOfWeek.SATURDAY ){
                        _settlementDate = _settlementDate.plusDays(2);
                    }
                    if(_settlementDate.getDayOfWeek() == DayOfWeek.SUNDAY ){
                        _settlementDate = _settlementDate.plusDays(1);
                    }
            }
        }
    }
    public FxTrade(String _entity, char _side, Double _agreedFx, Currency _currency, LocalDateTime _instructionDate, LocalDateTime _settlementDate, long _units, Double _pricePerUnit) {
        this._entity = _entity;
        this._side = _side;
        this._agreedFx = _agreedFx;
        this._currency = _currency;
        this._instructionDate = _instructionDate;
        this._settlementDate = _settlementDate;
        this._units = _units;
        this._pricePerUnit = _pricePerUnit;
        this.totalUSDCost = (_agreedFx * _units * _pricePerUnit);
        this.fixSettlementDate();
    }

    public FxTrade() {
        //Assign default/dummy values for empty trade object
        this._entity = "";
        this._side = '0';
        this._agreedFx = 0.0;
        this._currency = null;
        this._instructionDate = null;
        this._settlementDate = null;
        this._units = 0L;
        this._pricePerUnit = 0.0;
        this.totalUSDCost = (_agreedFx * _units * _pricePerUnit);
        this.fixSettlementDate();
    }

    public void printTrade(){
        System.out.print(this._entity); psep();
        System.out.print(this._side ); psep();
        System.out.print(this._agreedFx ); psep();

        if(null != _currency) {
            System.out.print(this._currency.toString());
        } psep();

        if(null != _instructionDate){
            System.out.print(this._instructionDate.toLocalDate().toString() );
        } psep();

        if(null != _settlementDate){
            System.out.print(this._settlementDate.toLocalDate().toString() );
        } psep();

        System.out.print(this._units ); psep();
        System.out.println(this._pricePerUnit);
    }
}
