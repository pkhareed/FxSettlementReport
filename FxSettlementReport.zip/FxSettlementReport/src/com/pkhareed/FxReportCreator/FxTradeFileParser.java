package com.pkhareed.FxReportCreator;

import FxReportCreatorInterfaces.FileParser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FxTradeFileParser implements FileParser {

    private String _fileName = "/Users/pavan/Downloads/fxtrades.csv";

    public FxTradeFileParser() {}
    public FxTradeFileParser(String FxTradesFile) {
        _fileName = FxTradesFile;
    }

    public ArrayList<String> readFile() {
        BufferedReader reader;
        ArrayList<String> lines = new ArrayList<>();
        try {
            reader = new BufferedReader(new FileReader(_fileName ));
            String line = reader.readLine();
            while (line != null) {
                //System.out.println(line);
                lines.add(line);

                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

}
