package com.pkhareed.FxReportCreator;

public enum Currency {
    USD,
    SAR,
    AED,
    INR,
    GBP,
    EUR,
    JPY,
    CAD,
    CHF,
    MYR,
    CNY,
    SGP
}
