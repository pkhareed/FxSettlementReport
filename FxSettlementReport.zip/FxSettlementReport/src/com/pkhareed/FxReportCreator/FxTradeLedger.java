package com.pkhareed.FxReportCreator;

import java.time.LocalDateTime;
import java.util.*;

public class FxTradeLedger {
    private HashMap<String,Double> _incomingSettlement = null;
    private HashMap<String,Double> _outgoingSettlement = null;
    private HashMap<String,Double> _incomingEntityRank = null;
    private HashMap<String,Double> _outgoingEntityRank = null;
    private void printLine(){
        System.out.println("--------------------------------");
    }

    public FxTradeLedger() {
        this._incomingSettlement = new HashMap<>();
        this._outgoingSettlement = new HashMap<>();
        this._incomingEntityRank = new HashMap<>();
        this._outgoingEntityRank = new HashMap<>();
    }

    public void storeTrade(FxTrade fxt){
        //Get the key metrics
        String settlementDay = fxt.get_settlementDate();
        Double fxtCost = fxt.get_totalUSDCost();
        Character side = fxt.get_side();
        String entity = fxt.get_entity();

        //Outgoing trade processing
        if(side == 'B'){
            if( _outgoingSettlement.computeIfPresent(settlementDay, (k, v) -> v+= fxtCost) == null ){
                _outgoingSettlement.put(settlementDay, fxtCost);
            }
            if( _outgoingEntityRank.computeIfPresent(entity, (k, v) -> v+= fxtCost) == null){
                _outgoingEntityRank.put(entity,fxtCost);
            }
        }
        else if(side == 'S'){ // Incoming trade processing
            if( _incomingSettlement.computeIfPresent(settlementDay, (k, v) -> v+= fxtCost) == null ){
                _incomingSettlement.put(settlementDay, fxtCost);
            }
            if( _incomingEntityRank.computeIfPresent(entity, (k, v) -> v+= fxtCost) == null){
                _incomingEntityRank.put(entity,fxtCost);
            }
        }
    }

    // function to sort hashmap by values
    public static HashMap<String, Double> sortByValue(HashMap<String, Double> hm)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Double> > list =
                new LinkedList<Map.Entry<String, Double> >(hm.entrySet());

        // Sort the list
        Collections.sort(list, new Comparator<Map.Entry<String, Double> >() {
            public int compare(Map.Entry<String, Double> o1,
                               Map.Entry<String, Double> o2)
            {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        // put data from sorted list to hashmap
        HashMap<String, Double> temp = new LinkedHashMap<String, Double>();
        for (Map.Entry<String, Double> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    // function to sort hashmap by keys
    public static HashMap<String, Double> sortByKeys(HashMap<String, Double> hm)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Double> > list =
                new LinkedList<Map.Entry<String, Double> >(hm.entrySet());

        // Sort the list
        Collections.sort(list, new Comparator<Map.Entry<String, Double> >() {
            public int compare(Map.Entry<String, Double> o1,
                               Map.Entry<String, Double> o2)
            {
                return (o2.getKey()).compareTo(o1.getKey());
            }
        });

        // put data from sorted list to hashmap
        HashMap<String, Double> temp = new LinkedHashMap<String, Double>();
        for (Map.Entry<String, Double> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    // Outgoing settlement report
    public void printOutgoingUSDReport(){
        printLine();
        System.out.println("Amount in USD settled - outgoing");
        printLine();
        System.out.println("Date\t\tAmount");
        // print the _outgoingSettlement hashmap

        for (Map.Entry<String, Double> ent : sortByKeys(_outgoingSettlement).entrySet()) {
            System.out.println(ent.getKey() + "\t" + ent.getValue());
        }
        System.out.println();
    }

    public void printIncomingUSDReport(){
        printLine();
        System.out.println("Amount in USD settled - incoming");
        printLine();
        System.out.println("Date\t\tAmount");
        // print the _incomingSettlement hashmap

        for (Map.Entry<String, Double> ent : sortByKeys(_incomingSettlement).entrySet()) {
            System.out.println(ent.getKey() + "\t" + ent.getValue());
        }
        System.out.println();

    }

    public void printIncomingEntityRankingReport(){
        printLine();
        System.out.println("Ranking of entities based on incoming ");
        printLine();
        System.out.println("Entity\t\tTotal Incoming Amount");
        // print the _incomingEntityRank hashmap

        for (Map.Entry<String, Double> ent : sortByValue(_incomingEntityRank).entrySet()) {
            System.out.println(ent.getKey() + "\t\t" + ent.getValue());
        }

        System.out.println();
    }

    public void printOutgoingEntityRankingReport(){
        printLine();
        System.out.println("Ranking of entities based on outgoing ");
        printLine();
        System.out.println("Entity\t\tTotal Outgoing Amount");
        // print the _outgoingEntityRank hashmap

        for (Map.Entry<String, Double> ent : sortByValue(_outgoingEntityRank).entrySet()) {
            System.out.println(ent.getKey() + "\t\t" + ent.getValue());
        }
        printLine();
    }

    public void printFullFxSummaryReport(){
        printLine();printLine();
        System.out.println("Fx Trades Summary Report");
        printLine();

        printOutgoingUSDReport();
        printIncomingUSDReport();
        printIncomingEntityRankingReport();
        printOutgoingEntityRankingReport();

    }
}
