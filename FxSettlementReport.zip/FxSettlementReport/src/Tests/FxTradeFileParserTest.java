package Tests;

import static org.junit.jupiter.api.Assertions.*;

class FxTradeFileParserTest {

}