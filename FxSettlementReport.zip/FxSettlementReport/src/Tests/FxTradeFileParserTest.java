package Tests;

import com.pkhareed.FxReportCreator.FxTradeFileParser;
import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class FxTradeFileParserTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @Test
    void readNoFile() {
        FxTradeFileParser fileParser = new FxTradeFileParser("");
        ArrayList<String> lines = fileParser.readFile();
        assertEquals("Error! While reading file", outContent.toString().trim());
    }

    @Test
    void readEmptyFile() {
        FxTradeFileParser fileParser = new FxTradeFileParser("empty.csv");
        ArrayList<String> lines = fileParser.readFile();
        assertEquals("", outContent.toString().trim());
        assertTrue(lines.isEmpty());
    }

    @Test
    void readRandomFile() {
        FxTradeFileParser fileParser = new FxTradeFileParser("random.txt");
        ArrayList<String> lines = fileParser.readFile();
        assertEquals("", outContent.toString().trim());
        assertEquals(lines.size(), 1);
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
    }
}