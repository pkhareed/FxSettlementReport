package Tests;

import com.pkhareed.FxReportCreator.Currency;
import com.pkhareed.FxReportCreator.FxTrade;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class FxTradeTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
    }

    @Test
    void get_entity() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals("",fxt.get_entity());
        assertEquals("foo",fxt2.get_entity());
    }

    @Test
    void get_side() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals('0',fxt.get_side());
        assertEquals('S',fxt2.get_side());
    }

    @Test
    void get_agreedFx() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(0.0,fxt.get_agreedFx());
        assertEquals(0.11,fxt2.get_agreedFx());
    }

    @Test
    void get_currency() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(null,fxt.get_currency());
        assertEquals(Currency.SGP,fxt2.get_currency());
    }

    @Test
    void get_instructionDate() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(null,fxt.get_instructionDate());
        assertEquals("2018-11-30",fxt2.get_instructionDate());
    }

    @Test
    void get_settlementDate() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(null,fxt.get_settlementDate());
        assertEquals("2018-12-03",fxt2.get_settlementDate());
    }

    @Test
    void get_units() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(0,fxt.get_units());
        assertEquals(5,fxt2.get_units());
    }

    @Test
    void get_pricePerUnit() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(0.0,fxt.get_pricePerUnit());
        assertEquals(20.0,fxt2.get_pricePerUnit());
    }

    @Test
    void get_totalUSDCost() {
        FxTrade fxt = new FxTrade();
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        assertEquals(0.0,fxt.get_totalUSDCost());
        assertEquals(11.0,fxt2.get_totalUSDCost());
    }

    @Test
    void nullTrade() {
        assertDoesNotThrow(() -> {
            FxTrade fxt = new FxTrade();
        });
    }

    @Test
    void printDummyTrade() {
        FxTrade fxt = new FxTrade();
        fxt.printTrade();
        assertEquals(", 0, 0.0, , , , 0, 0.0", outContent.toString().trim());
    }

    @Test
    void printSARTradeFixDate() {
        FxTrade fxt = new FxTrade("foo",'S',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
                );
        fxt.printTrade();
        assertEquals("foo, S, 0.11, SAR, 2018-11-30, 2018-12-02, 5, 20.0", outContent.toString().trim());
    }


    @Test
    void printSARTradeNoFixDate() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,02,0,0),
                5, 20.0
        );
        fxt.printTrade();
        assertEquals("foo, B, 0.11, SAR, 2018-11-30, 2018-12-02, 5, 20.0", outContent.toString().trim());
    }

    @Test
    void printSGPTradeFixDate() {
        FxTrade fxt = new FxTrade("foo",'S',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        fxt.printTrade();
        assertEquals("foo, S, 0.11, SGP, 2018-11-30, 2018-12-03, 5, 20.0", outContent.toString().trim());
    }


    @Test
    void printSGPTradeNoFixDate() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SGP,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,04,0,0),
                5, 20.0
        );
        fxt.printTrade();
        assertEquals("foo, B, 0.11, SGP, 2018-11-30, 2018-12-04, 5, 20.0", outContent.toString().trim());
    }
}