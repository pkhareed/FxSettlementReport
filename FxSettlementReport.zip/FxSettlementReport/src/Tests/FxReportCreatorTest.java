package Tests;

import com.pkhareed.FxReportCreator.FxReportCreator;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

class FxReportCreatorTest {

    @Test
    void main() {
        assertDoesNotThrow(() -> {
            FxReportCreator.main(null);
        });
    }
}