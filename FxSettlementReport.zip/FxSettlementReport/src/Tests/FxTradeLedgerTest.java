package Tests;

import com.pkhareed.FxReportCreator.Currency;
import com.pkhareed.FxReportCreator.FxTrade;
import com.pkhareed.FxReportCreator.FxTradeLedger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class FxTradeLedgerTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    private FxTradeLedger fxLedger = null;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
        fxLedger = new FxTradeLedger();
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
        fxLedger = null;
    }

    @Test
    void storeDummyTrade() {
        FxTrade fxt = new FxTrade();
        fxLedger.storeTrade(fxt);
        fxLedger.printFullFxSummaryReport();
        assertEquals("--------------------------------\n" +
                "--------------------------------\n" +
                "Fx Trades Summary Report\n" +
                "--------------------------------\n" +
                "--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "\n" +
                "--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "--------------------------------",outContent.toString().trim());
    }

    @Test
    void storeValidSellTrade() {
        FxTrade fxt = new FxTrade("foo",'S',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printFullFxSummaryReport();
        assertEquals("--------------------------------\n" +
                "--------------------------------\n" +
                "Fx Trades Summary Report\n" +
                "--------------------------------\n" +
                "--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "\n" +
                "--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-02\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount\n" +
                "foo\t\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "--------------------------------",outContent.toString().trim());
    }

    @Test
    void storeValidBuyTrade() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printFullFxSummaryReport();
        assertEquals("--------------------------------\n" +
                "--------------------------------\n" +
                "Fx Trades Summary Report\n" +
                "--------------------------------\n" +
                "--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-05\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "foo\t\t11.0\n" +
                "--------------------------------",outContent.toString().trim());
    }


    @Test
    void storeValidBuySellTrade() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        FxTrade fxt2 = new FxTrade("foo",'S',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,01,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);fxLedger.storeTrade(fxt2);
        fxLedger.printFullFxSummaryReport();
        assertEquals("--------------------------------\n" +
                "--------------------------------\n" +
                "Fx Trades Summary Report\n" +
                "--------------------------------\n" +
                "--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-05\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-02\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount\n" +
                "foo\t\t11.0\n" +
                "\n" +
                "--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "foo\t\t11.0\n" +
                "--------------------------------",outContent.toString().trim());
    }

    @Test
    void sortByValue() {
        HashMap<String, Double> hm = new HashMap<String, Double>();

        // enter data into hashmap
        hm.put("Math", 98.0);
        hm.put("Data Structure", 85.0);
        hm.put("Database", 91.0);
        hm.put("Java", 95.0);
        hm.put("Operating System", 79.0);
        hm.put("Networking", 80.0);
        Map<String, Double> hm1 = fxLedger.sortByValue(hm);

        // print the sorted hashmap
        for (Map.Entry<String, Double> en : hm1.entrySet()) {
            System.out.print(en.getKey() +
                    "=" + en.getValue() + ",");
        }
        assertEquals("Math=98.0,Java=95.0,Database=91.0,Data Structure=85.0,Networking=80.0,Operating System=79.0,",
                outContent.toString().trim());
    }

    @Test
    void sortByKeys() {
        HashMap<String, Double> hm = new HashMap<String, Double>();

        // enter data into hashmap
        hm.put("Math", 98.0);
        hm.put("Data Structure", 85.0);
        hm.put("Database", 91.0);
        hm.put("Java", 95.0);
        hm.put("Operating System", 79.0);
        hm.put("Networking", 80.0);
        Map<String, Double> hm1 = fxLedger.sortByKeys(hm);

        // print the sorted hashmap
        for (Map.Entry<String, Double> en : hm1.entrySet()) {
            System.out.print(en.getKey() +
                    "=" + en.getValue() + ",");
        }
        assertEquals("Operating System=79.0,Networking=80.0,Math=98.0,Java=95.0,Database=91.0,Data Structure=85.0,",
                outContent.toString().trim());
    }

    @Test
    void printEmptyOutgoingUSDReport() {
        FxTrade fxt = new FxTrade();
        fxLedger.storeTrade(fxt);
        fxLedger.printOutgoingUSDReport();
        assertEquals("--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount",outContent.toString().trim());
    }

    @Test
    void printOutgoingUSDReport() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printOutgoingUSDReport();
        assertEquals("--------------------------------\n" +
                "Amount in USD settled - outgoing\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-05\t11.0",outContent.toString().trim());
    }

    @Test
    void printEmptyprintIncomingUSDReport() {
        FxTrade fxt = new FxTrade();
        fxLedger.storeTrade(fxt);
        fxLedger.printIncomingUSDReport();
        assertEquals("--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount",outContent.toString().trim());
    }

    @Test
    void printIncomingUSDReport() {
        FxTrade fxt = new FxTrade("foo",'S',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printIncomingUSDReport();
        assertEquals("--------------------------------\n" +
                "Amount in USD settled - incoming\n" +
                "--------------------------------\n" +
                "Date\t\tAmount\n" +
                "2018-12-05\t11.0",outContent.toString().trim());
    }

    @Test
    void printEmptyIncomingEntityRankingReport() {
        FxTrade fxt = new FxTrade();
        fxLedger.storeTrade(fxt);
        fxLedger.printIncomingEntityRankingReport();
        assertEquals("--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount",outContent.toString().trim());
    }

    @Test
    void printIncomingEntityRankingReport() {
        FxTrade fxt = new FxTrade("foo",'S',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printIncomingEntityRankingReport();
        assertEquals("--------------------------------\n" +
                "Ranking of entities based on incoming \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Incoming Amount\n" +
                "foo\t\t11.0",outContent.toString().trim());
    }

    @Test
    void printEmptyOutgoingEntityRankingReport() {
        FxTrade fxt = new FxTrade();
        fxLedger.storeTrade(fxt);
        fxLedger.printOutgoingEntityRankingReport();
        assertEquals("--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "--------------------------------",outContent.toString().trim());
    }

    @Test
    void printOutgoingEntityRankingReport() {
        FxTrade fxt = new FxTrade("foo",'B',0.11, Currency.SAR,
                LocalDateTime.of(2018,11,30,0,0),
                LocalDateTime.of(2018,12,05,0,0),
                5, 20.0
        );
        fxLedger.storeTrade(fxt);
        fxLedger.printOutgoingEntityRankingReport();
        assertEquals("--------------------------------\n" +
                "Ranking of entities based on outgoing \n" +
                "--------------------------------\n" +
                "Entity\t\tTotal Outgoing Amount\n" +
                "foo\t\t11.0\n" +
                "--------------------------------",outContent.toString().trim());
    }
}