package FxReportCreatorInterfaces;

import java.util.ArrayList;

public interface FileParser {
    ArrayList<String> readFile();
}
